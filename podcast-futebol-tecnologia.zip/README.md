# 🎙️ Projeto Podcast Gerado por I.A.s
## Episódio: Como o Futebol e a Tecnologia se Conectam

Este projeto demonstra como é possível criar um podcast completo utilizando Inteligência Artificial e uma esteira de prompts bem estruturada.

## ⚙️ Tecnologias utilizadas
- ChatGPT → Criação do roteiro
- ElevenLabs → Voz e narração
- Midjourney → Capas e visuais
- CapCut → Edição e mixagem final

## 📁 Estrutura do projeto
```
📁 podcast-futebol-tecnologia/
├── roteiro.txt
├── audio/
├── imagens/
├── projetos_capcut/
└── README.md
```

## 🧩 Tema
**Como o Futebol e a Tecnologia se Conectam**

## ✨ Autor
**João Lucas Lima Silva**  
🎓 Formado em Contabilidade | 💻 Cursando Tecnologia da Informação | 🎙️ Criador de Conteúdo com IA
